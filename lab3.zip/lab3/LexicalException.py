class LexicalException(Exception):
    pass